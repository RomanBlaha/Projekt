﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class SqlRepository
    {
        public static readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Administration;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
    
        public static List<Pracant> Display()
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "SELECT * FROM Pracant";
            SqlDataReader reader = cmd.ExecuteReader();
            List<Pracant> pracant  = new List<Pracant>();
            while (reader.Read())
            {
                pracant.Add(new Pracant(reader.GetInt32(0),reader.GetString(1),reader.GetString(2), reader.GetString(3),reader.GetDateTime(4)));
            }
            reader.Close();
            conn.Close();
            return pracant;
        }
        public static void Addd(Pracant pracant)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "INSERT INTO Pracant VALUES (@Name,@LastName,@PhoneNumber,@Birthday)";
            cmd.Parameters.AddWithValue("Name", pracant.Name);
            cmd.Parameters.AddWithValue("LastName", pracant.LastName);
            cmd.Parameters.AddWithValue("PhoneNumber", pracant.PhoneNumber);
            cmd.Parameters.AddWithValue("Birthday", pracant.Birthday);
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public static void Delete(string Id)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText= $"DELETE Pracant WHERE Id={Id}";
            cmd.ExecuteNonQuery();
            conn.Close();
        }
        public static void Update(int Id, Pracant pracant) 
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand cmd = conn.CreateCommand();
            cmd.CommandText = "UPDATE Pracant SET Jmeno=@Name, Prijmeni=@LastName, TelCislo=@PhoneNumber, rokNar=@Birthday WHERE Id=@Id";
            cmd.Parameters.AddWithValue("Id", Id);
            cmd.Parameters.AddWithValue("Name", pracant.Name);
            cmd.Parameters.AddWithValue("LastName", pracant.LastName);
            cmd.Parameters.AddWithValue("PhoneNumber", pracant.PhoneNumber);
            cmd.Parameters.AddWithValue("Birthday", pracant.Birthday);
            cmd.ExecuteNonQuery(); 
            conn.Close();

        }
    }
}
