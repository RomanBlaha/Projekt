﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal class Pracant

    {
        

        public int Id { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime Birthday { get; set; }
        
        public Pracant(int id, string name, string lastName, string phoneNumber, DateTime birthday)
        {
            Id = id;
            Name = name;
            LastName = lastName;
            PhoneNumber = phoneNumber;
            Birthday = birthday;
        }
        public Pracant(string name, string lastName, string phoneNumber, DateTime birthday)
        {
            
            Name = name;
            LastName = lastName;
            PhoneNumber = phoneNumber;
            Birthday = birthday;
        }

        public ListViewItem ToListViewItem()
        {
            return new ListViewItem(new string[] { Id.ToString(), Name, LastName, PhoneNumber, Birthday.ToShortDateString() });   
        }


    }
}
